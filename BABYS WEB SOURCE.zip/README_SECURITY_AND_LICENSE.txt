================================================================================
🛡️ BABYS CLIPPER — WEB SOURCE CODE ARCHIVE & SECURITY LOCK
================================================================================
Project: Babys Clipper (AI 2.0)
Owner / Creator: @Ogxbabby
Telegram Channel / DM: https://t.me/Ogxbabby
Discord Community: https://discord.gg/VdJN88sfbh
Emergency Trigger Passphrase: RUN THIS CODE-I AM BABY
Default URL: http://localhost:8080

--------------------------------------------------------------------------------
👑 OWNER & COMMUNITY DETAILS
--------------------------------------------------------------------------------
- Telegram: https://t.me/Ogxbabby
- Discord: https://discord.gg/VdJN88sfbh
- Platform: Babys Clipper AI 2.0 Live Stream Automation

--------------------------------------------------------------------------------
🔒 ANTI-COPY & BRAND INTEGRITY LOCKS ENFORCED
--------------------------------------------------------------------------------
1. BRAND INTEGRITY LOCK:
   - All branding ('BABYS CLIPPER' and '@Ogxbabby') is protected by client-side
     MutationObservers and watchdog timers. Any attempt to modify the DOM, title,
     watermarks, or profile pictures is automatically reverted in real time.
2. DEVELOPER TOOL & SHORTCUT INTERCEPTOR:
   - F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C, Ctrl+U, and Ctrl+S are blocked.
3. CONTEXT MENU & SELECTION LOCK:
   - Right-click and text selection across dashboard content are restricted.
4. ONLY REAL VIDEOS DISPLAYED:
   - Only videos actually existing in the file system are displayed. Zero fake/dummy cards.
   - Thumbnails are extracted directly from each video clip.

--------------------------------------------------------------------------------
⚡ MANDATORY AUTOMATION RULES
--------------------------------------------------------------------------------
Rule 01: Shorts >= 50s (Strictly 50s to 60s)
Rule 02: Minimum 2 Full Mission Videos >= 5 min (Strictly >= 300s)
Rule 03: Complete 00:00:00 to End Stream Coverage & Zero Repetition
Rule 04: Animated Live Word-by-Word Captions (Dynamic pop & highlight animation)
Rule 05: No Watermark on Videos (Pure clean footage, zero watermark overlay)
Rule 06: Dedicated link folder per stream
Rule 07: Creator folder with 2 subfolders: SHORT_VIDEOS/ and LONG_VIDEOS/
Rule 08: Title, description, Instagram caption & viral hashtags with every video
Rule 09: Only real videos displayed on dashboard with real extracted thumbnails
================================================================================
