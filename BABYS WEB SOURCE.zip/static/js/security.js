/**
 * ============================================================================
 * 🛡️ BABYS CLIPPER — CORE SECURITY, ANTI-TAMPER & BRAND LOCK ENGINE
 * Owner & Creator: @Ogxbabby
 * Emergency Trigger: RUN THIS CODE-I AM BABY
 * ============================================================================
 * This script enforces complete client-side brand protection, prevents unauthorized
 * copying, blocks developer inspect shortcuts, and auto-restores brand elements
 * if any tampering is attempted in the DOM or DevTools.
 */

(function () {
  'use strict';

  // 1. Immutable Brand Configuration
  const BRAND_VAULT = Object.freeze({
    appName: 'BABYS CLIPPER',
    primary: 'BABYS',
    accent: 'CLIPPER',
    watermark: '@Ogxbabby',
    pfpUrl: '/static/img/babys_pfp.jpg',
    title: 'Babys Clipper - Live Stream AI Clipper & Social Media Automation',
    license: 'PROPRIETARY & ENCRYPTED — ALL RIGHTS RESERVED TO @Ogxbabby',
    passphrase: 'RUN THIS CODE-I AM BABY'
  });

  // Make immutable globally
  try {
    Object.defineProperty(window, 'BABYS_SECURITY_VAULT', {
      value: BRAND_VAULT,
      writable: false,
      configurable: false
    });
  } catch (e) {}

  // 2. High-Tech Cyber Console Shield
  function printConsoleBanner() {
    try {
      const art = `
%c██████╗  █████╗ ██████╗ ██╗   ██╗███████╗     ██████╗██╗     ██╗██████╗ ██████╗ ███████╗██████╗ 
██╔══██╗██╔══██╗██╔══██╗╚██╗ ██╔╝██╔════╝    ██╔════╝██║     ██║██╔══██╗██╔══██╗██╔════╝██╔══██╗
██████╔╝███████║██████╔╝ ╚████╔╝ ███████╗    ██║     ██║     ██║██████╔╝██████╔╝█████╗  ██████╔╝
██╔══██╗██╔══██║██╔══██╗  ╚██╔╝  ╚════██║    ██║     ██║     ██║██╔═══╝ ██╔═══╝ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██████╔╝   ██║   ███████║    ╚██████╗███████╗██║██║     ██║     ███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═════╝    ╚═╝   ╚══════╝     ╚═════╝╚══════╝╚═╝╚═╝     ╚═╝     ╚══════╝╚═╝  ╚═╝
`;
      console.log(art, 'color: #ff1e42; font-weight: 900; font-family: monospace;');
      console.log(
        '%c🔒 BABYS CLIPPER ACTIVE INTEGRITY SHIELD %c\n' +
        '👑 CREATOR & EXCLUSIVE OWNER: @Ogxbabby\n' +
        '⚡ STATUS: BRAND-LOCKED & ANTI-TAMPER PROTECTED\n' +
        '⛔ UNAUTHORIZED CODE COPYING, NAME CHANGE, OR REMOVAL OF WATERMARKS IS PROHIBITED.',
        'background: #ff1e42; color: #fff; font-weight: bold; padding: 4px 10px; border-radius: 4px;',
        'color: #38bdf8; font-weight: bold; font-family: sans-serif;'
      );
    } catch (e) {}
  }

  // 3. Right-Click Context Menu Lock
  document.addEventListener('contextmenu', function (e) {
    // Allow right click only inside form inputs/textareas for pasting
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
      return;
    }
    e.preventDefault();
    showSecurityToast('🔒 Protected by @Ogxbabby: Right-click & source inspection is locked on BABYS CLIPPER!');
  }, false);

  // 4. Keyboard Shortcuts Interceptor (F12, Ctrl+Shift+I, Ctrl+U, etc.)
  document.addEventListener('keydown', function (e) {
    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const ctrlKey = isMac ? e.metaKey : e.ctrlKey;

    // F12 DevTools
    if (e.key === 'F12' || e.keyCode === 123) {
      e.preventDefault();
      triggerTamperAlert('Developer Tools shortcut (F12) blocked by Security Shield.');
      return false;
    }

    // Ctrl + Shift + I (Inspect)
    if (ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.keyCode === 73)) {
      e.preventDefault();
      triggerTamperAlert('Inspect Element shortcut (Ctrl+Shift+I) blocked.');
      return false;
    }

    // Ctrl + Shift + J (Console)
    if (ctrlKey && e.shiftKey && (e.key === 'J' || e.key === 'j' || e.keyCode === 74)) {
      e.preventDefault();
      triggerTamperAlert('Console shortcut (Ctrl+Shift+J) blocked.');
      return false;
    }

    // Ctrl + Shift + C (Element Inspector)
    if (ctrlKey && e.shiftKey && (e.key === 'C' || e.key === 'c' || e.keyCode === 67)) {
      e.preventDefault();
      triggerTamperAlert('Element Picker shortcut (Ctrl+Shift+C) blocked.');
      return false;
    }

    // Ctrl + U (View Source)
    if (ctrlKey && (e.key === 'u' || e.key === 'U' || e.keyCode === 85)) {
      e.preventDefault();
      triggerTamperAlert('View Source shortcut (Ctrl+U) blocked.');
      return false;
    }

    // Ctrl + S (Save Page)
    if (ctrlKey && (e.key === 's' || e.key === 'S' || e.keyCode === 83)) {
      e.preventDefault();
      showSecurityToast('🔒 Page saving is disabled. Babys Clipper is proprietary to @Ogxbabby.');
      return false;
    }

    // Ctrl + P (Print Page)
    if (ctrlKey && (e.key === 'p' || e.key === 'P' || e.keyCode === 80)) {
      e.preventDefault();
      return false;
    }
  }, false);

  // 5. Image Dragging Prevention
  document.addEventListener('dragstart', function (e) {
    if (e.target.tagName === 'IMG') {
      e.preventDefault();
      return false;
    }
  }, false);

  // 6. Active Brand Lock & DOM Mutation Observer
  function enforceBrandIntegrity() {
    let tampered = false;

    // Check Window Title
    if (!document.title.includes('Babys Clipper')) {
      document.title = BRAND_VAULT.title;
      tampered = true;
    }

    // Check Primary Brand Text
    const primaryEls = document.querySelectorAll('.brand-primary');
    primaryEls.forEach(el => {
      if (el.textContent.trim() !== BRAND_VAULT.primary) {
        el.textContent = BRAND_VAULT.primary;
        tampered = true;
      }
    });

    // Check Accent Brand Text
    const accentEls = document.querySelectorAll('.brand-accent');
    accentEls.forEach(el => {
      if (el.textContent.trim() !== BRAND_VAULT.accent) {
        el.textContent = BRAND_VAULT.accent;
        tampered = true;
      }
    });

    // Check Watermarks
    const watermarks = document.querySelectorAll('.watermark-tag, .brand-owner');
    watermarks.forEach(el => {
      if (!el.textContent.includes(BRAND_VAULT.watermark)) {
        el.textContent = BRAND_VAULT.watermark;
        tampered = true;
      }
    });

    // Check PFP image source
    const pfpImgs = document.querySelectorAll('.pfp-img, #user-pfp');
    pfpImgs.forEach(img => {
      if (!img.getAttribute('src').includes('babys_pfp.jpg')) {
        img.src = BRAND_VAULT.pfpUrl;
        tampered = true;
      }
    });

    // Check Security Badge Presence
    const badge = document.getElementById('security-lock-badge');
    if (!badge || badge.style.display === 'none' || badge.style.visibility === 'hidden') {
      createSecurityBadge();
      tampered = true;
    }

    if (tampered) {
      showSecurityToast('🛡️ Auto-Reverted: Brand name or watermark modification is locked by @Ogxbabby!');
    }
  }

  // 7. Security Toast Display
  function showSecurityToast(msg) {
    let toast = document.getElementById('security-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'security-toast';
      toast.className = 'security-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('active');
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
      toast.classList.remove('active');
    }, 3200);
  }

  // 8. Tamper Alert Modal
  function triggerTamperAlert(reason) {
    let modal = document.getElementById('tamper-alert-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'tamper-alert-modal';
      modal.className = 'tamper-modal';
      modal.innerHTML = `
        <div class="tamper-card">
          <div class="tamper-icon">🚨</div>
          <h2 class="tamper-title">SECURITY & BRAND LOCK ACTIVE</h2>
          <div class="tamper-brand-box">
            <div><strong>PLATFORM:</strong> BABYS CLIPPER (AI 2.0)</div>
            <div><strong>OWNER:</strong> @Ogxbabby</div>
            <div><strong>STATUS:</strong> TAMPER-RESISTANT VAULT</div>
          </div>
          <p class="tamper-desc" id="tamper-desc-msg">
            ${reason || 'Unauthorized inspection, name alteration, or code copying attempt detected.'}
          </p>
          <p style="font-size: 12px; color: #ff1e42; margin-bottom: 20px; font-weight: 600;">
            All branding, title, watermarks, and media are strictly locked to protect original authorship.
          </p>
          <button class="btn-tamper-close" onclick="closeTamperModal()">
            <span>I UNDERSTAND & COMPLY</span>
          </button>
        </div>
      `;
      document.body.appendChild(modal);
    } else {
      const msgEl = document.getElementById('tamper-desc-msg');
      if (msgEl) msgEl.textContent = reason;
    }
    modal.style.display = 'flex';
  }

  window.closeTamperModal = function () {
    const modal = document.getElementById('tamper-alert-modal');
    if (modal) modal.style.display = 'none';
  };

  // 9. Floating Brand Security Badge
  function createSecurityBadge() {
    let badge = document.getElementById('security-lock-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.id = 'security-lock-badge';
      badge.className = 'security-lock-badge';
      badge.innerHTML = `
        <span class="lock-icon">🔒</span>
        <span class="lock-brand">BABYS CLIPPER</span>
        <span class="lock-sep">•</span>
        <span class="lock-owner">@Ogxbabby</span>
        <span class="lock-tag">LOCKED</span>
      `;
      badge.onclick = function () {
        triggerTamperAlert('BABYS CLIPPER is protected with Active Brand-Lock Integrity Shield by @Ogxbabby.');
      };
      document.body.appendChild(badge);
    }
    badge.style.display = 'flex';
    badge.style.visibility = 'visible';
  }

  // 10. Initialization & Watchdog Observers
  function initProtection() {
    printConsoleBanner();
    createSecurityBadge();
    enforceBrandIntegrity();

    // DOM MutationObserver to catch real-time tampering
    const observer = new MutationObserver(function (mutations) {
      let shouldCheck = false;
      for (let m of mutations) {
        if (m.type === 'characterData' || m.type === 'childList' || m.type === 'attributes') {
          shouldCheck = true;
          break;
        }
      }
      if (shouldCheck) {
        enforceBrandIntegrity();
      }
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['class', 'src', 'style', 'id']
    });

    // Heartbeat Watchdog every 500ms
    setInterval(enforceBrandIntegrity, 500);
  }

  // Hook into DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initProtection);
  } else {
    initProtection();
  }

})();
