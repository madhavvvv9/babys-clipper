#!/usr/bin/env bash
export PORT=${PORT:-8080}
export HOST=${HOST:-0.0.0.0}
echo "Starting Babys Clipper Web Server on http://$HOST:$PORT..."
python3 server.py
