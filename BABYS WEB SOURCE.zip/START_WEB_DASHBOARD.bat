@echo off
title BABYS CLIPPER - Web Dashboard & Automation Portal
color 0C
cls
echo ===================================================================
echo  ⚡ BABYS CLIPPER WEB DASHBOARD & VIRAL SOCIAL ENGINE
echo  ⚡ EXCLUSIVE OWNER & BRAND: @Ogxbabby
echo  ⚡ TRIGGER PASSPHRASE: RUN THIS CODE-I AM BABY
echo  ⚡ STATUS: BRAND-LOCKED & ANTI-TAMPER SECURED
echo ===================================================================
echo.
echo Launching Babys Clipper on http://localhost:8080 ...

cd /d "%~dp0"

start http://localhost:8080

:: Check if uv exists
where uv >nul 2>nul
if %errorlevel% equ 0 (
    echo [OK] Using uv runtime...
    uv run python server.py
    goto end
)

:: Check if python exists
where python >nul 2>nul
if %errorlevel% equ 0 (
    echo [OK] Using python runtime...
    python server.py
    goto end
)

:: Check user gemini uv
if exist "%USERPROFILE%\.gemini\antigravity\bin\uv.exe" (
    echo [OK] Using Antigravity uv runtime...
    "%USERPROFILE%\.gemini\antigravity\bin\uv.exe" run python server.py
    goto end
)

echo [ERROR] Python or uv runtime not detected on this system.
pause

:end
